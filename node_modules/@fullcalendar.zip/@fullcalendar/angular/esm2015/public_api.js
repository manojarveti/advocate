/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of fullcalendar
 */
export { FullCalendarComponent } from './lib/fullcalendar.component';
export { FullCalendarModule } from './lib/fullcalendar.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BmdWxsY2FsZW5kYXIvYW5ndWxhci8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUlBLHNDQUFjLDhCQUE4QixDQUFDO0FBQzdDLG1DQUFjLDJCQUEyQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBmdWxsY2FsZW5kYXJcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9mdWxsY2FsZW5kYXIuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2Z1bGxjYWxlbmRhci5tb2R1bGUnO1xuIl19