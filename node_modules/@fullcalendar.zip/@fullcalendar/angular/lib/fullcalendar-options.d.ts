export declare const INPUT_NAMES: string[];
export declare const INPUT_IS_DEEP: {
    header: boolean;
    footer: boolean;
    events: boolean;
    eventSources: boolean;
    resources: boolean;
};
export declare const OUTPUT_NAMES: string[];
