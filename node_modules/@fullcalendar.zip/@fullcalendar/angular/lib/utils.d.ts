export declare function deepCopy(input: any): any;
