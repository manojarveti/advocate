<?php
/**
 * Returns the list of cars.
 */
require '../connect.php';
// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
$time=date("H:i:s");
$date=date("Y-m-d");	
$notes = mysqli_real_escape_string($con, trim($request->data->notes));

$sql ="INSERT INTO `markin`(`id`, `notes`, `date`, `time`) VALUES (null,'{$notes}','{$date}','{$time}')";
 if(mysqli_query($con,$sql))
  {
	  $add = [
	  'notes' => $notes,
	  'date' => $date,
	  'time' => $time,
      'id'    => mysqli_insert_id($con)
    ];
    echo json_encode(['data'=>$add]);
  }
}
?>